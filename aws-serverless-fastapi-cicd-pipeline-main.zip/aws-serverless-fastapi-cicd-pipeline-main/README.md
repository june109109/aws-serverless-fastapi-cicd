# AWS Lambda FastAPI CI/CD Pipeline using GitHub Actions
This project repository contains the github actions workflow of CI/CD Pipeline for FastAPI to AWS Lambda.
<a href="https://medium.com/thelorry-product-tech-data/aws-lambda-fastapi-ci-cd-pipeline-with-github-actions-c414866b2d48?source=friends_link&sk=2c9da7df659020527ad7605dd3b96999">Click Here to read the full article/tutorial!</a>
